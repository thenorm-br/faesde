oopcao invalida



<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>

<script>
   $(document).ready(function() {
 
      var ua = navigator.userAgent;
      var isSafari = /^((?!chrome|android).)*safari/i.test(ua);

      // Check if it is not a mobile device
      var isDesktop = !/Mobi|Android/i.test(ua);

      if (isSafari && isDesktop) {
         $("#start").css('display', 'none');
         $(".inputSend").css('width', 'calc(100% - 32px)');
      }
   });


   function baixarConversa() {
    window.open('chatpdf/baixarConversaMoni.php', '_blank');
   // console.log('ola');
}

// function baixarConversa() {
//             $.post('chatpdf/baixarConversa.php', function(pdfUrl) {
//                 // Abre o PDF em uma nova aba
//                 window.open(pdfUrl, '_blank');
//             });
//         } 
</script>